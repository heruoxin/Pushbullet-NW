#Pushbullet-NW

Unofficial pushbullet node-webkit OS X client.

##Feature

- Design for Yosemite. Support Notification Center.
- Receive & send all type of push: note, link, address, list, and picture.
- Mirror notification from Android device. Click to open on Mac or web.
- Send & receive sms.
- Universal Copy & paste.

##Download

[link](https://github.com/heruoxin/Pushbullet-NW/blob/release-download/Pushbullet-NW.app.zip?raw=true)

##Screenshot

![screenshot](https://www.1ittlecup.com/files/Pushbullet-NW/0.1.5/screenshot.png)

##Acknowledgements

[Node-Webkit](https://github.com/rogerwang/node-webkit)

[jQuery](http://jquery.com/)

[Waves](https://github.com/fians/Waves)

[node-form-data](https://gemnasium.com/felixge/node-form-data)

[flaticon.com](http://www.flaticon.com/)'s icons.

[@satellitemx](http://https://twitter.com/satellitemx)'s help for CSS.

……_(:3 」∠)_……

