#Pushbullet-NW

Unofficial pushbullet node-webkit OS X client.

##Feature

- Design for Yosemite. Support Notification Center.
- Receive & send note, link, address, list, and picture.
- Mirror notification from Android Device.
- Send & receive sms.

##Download

[v0.1.6](https://github.com/heruoxin/Pushbullet-NW/blob/release-download/Pushbullet-NW.app.zip?raw=true)

##Screenshot

![screenshot](https://www.1ittlecup.com/files/Pushbullet-NW/0.1.5/screenshot.png)

##Thanks

[flaticon.com](http://www.flaticon.com/)'s icons.

[@satellitemx](http://https://twitter.com/satellitemx)'s help for CSS.

……_(:3 」∠)_……

