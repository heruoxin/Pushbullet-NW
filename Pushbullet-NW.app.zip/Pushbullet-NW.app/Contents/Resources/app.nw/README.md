#Pushbullet-NW

Unofficial pushbullet node-webkit OS X client.

##Feature

- Design for Yosemite. Support Notification Center.
- Receive & send note, link, address, list, and picture.
- Mirror notification from Android Device.
- Register as a device in pushbullet. You can push note from other client to Mac.

##Download

[v0.1.5](https://www.1ittlecup.com/files/Pushbullet-NW/0.1.5/Pushbullet-nw.app.zip)

##Screenshot

<video >
<source src="https://www.1ittlecup.com/files/Pushbullet-NW/0.1.3/screenRecord.mp4" type="video/mov">
</video>

![screenshot](https://www.1ittlecup.com/files/Pushbullet-NW/0.1.1/screenshot.png)

##Thanks

[flaticon.com](http://www.flaticon.com/)'s icons.

[@satellitemx](http://https://twitter.com/satellitemx)'s help for CSS.

……_(:3 」∠)_……

